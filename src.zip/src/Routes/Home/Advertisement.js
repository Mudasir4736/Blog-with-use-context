

import '../../App.css'

const Advertisement = () => {

  return (
    <div className='Ad'>
        <iframe width="300" height="150"src="https://www.youtube.com/embed/tgbNymZ7vqY?autoplay=1&mute=1" >
</iframe>
<iframe width="300" height="150"src="https://www.youtube.com/embed/tgbNymZ7vqY?autoplay=1&mute=1" >
</iframe>
<iframe width="300" height="150"src="https://www.youtube.com/embed/tgbNymZ7vqY?autoplay=1&mute=1" >
</iframe>
    </div>
  )
}

export default Advertisement

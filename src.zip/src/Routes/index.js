import Home from "./Home";
import Bollywood from "./Bollywood";
import Technology from "./Technology";
import Hollywood from "./Hollywood";
import Fitness from "./Fitness";
import Food from "./Food";
import CommonPage from "./StaticPage";

export {Home, Bollywood, Technology, Hollywood, Fitness, Food, CommonPage}
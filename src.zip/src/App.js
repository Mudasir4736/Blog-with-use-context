
import './App.css';
import StaticPage from './Routes/StaticPage';



import AppRoutes from './Utility/Routers';


function App() {
  return (
    <div className="App">
   
      <AppRoutes/>
   {/* <StaticPage/> */}
     
      
    </div>
  );
}

export default App;

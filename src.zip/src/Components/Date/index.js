import React from 'react'
import '../../App.css'

const Date = ({date}) => {
  return (
    <>
      <span className='genericDate'>{date}</span>
    </>
  )
}

export default Date

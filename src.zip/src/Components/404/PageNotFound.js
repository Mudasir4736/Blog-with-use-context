import React from 'react'
import '../../App.css'

function PageNotFound() {
  return (
    <div>
      <h1 className='Error404'>Error 404 - Page not found</h1>
    </div>
  )
}

export default PageNotFound

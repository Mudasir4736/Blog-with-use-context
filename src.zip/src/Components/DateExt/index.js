import React from 'react'
import '../../App.css'

const DateExt = ({dateExt}) => {
  return (
    <>
      <span className='genericDateExt'>{dateExt}</span>
    </>
  )
}

export default DateExt

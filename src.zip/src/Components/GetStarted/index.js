import React from 'react'
import './getStarted.style.css'

function GetStarted() {
  return (
    <div>
      <p className='getText'>Get started</p>
    </div>
  )
}

export default GetStarted

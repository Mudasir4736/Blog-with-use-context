// import React, {useContext} from "react";
// import { AppData } from "./contextAPI";

// function MockData(){
//     const [state] = useContext(AppData)
//     console.log(state);
//     return(
//         <>
//         <div> Working </div>
//         </>
//     )
// }

// export default MockData
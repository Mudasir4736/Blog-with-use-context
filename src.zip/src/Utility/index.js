import { AppData } from "./ContextStore/contextAPI";

export {AppData };